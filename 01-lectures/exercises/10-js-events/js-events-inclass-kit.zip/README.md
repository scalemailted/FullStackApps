# JS Events — In‑Class Exercise Kit

This kit contains a **starter** and a **solution** for a 30–45 minute in‑class exercise on JavaScript events.

## Tasks
1. **Event Logger** — attach listeners to log event details (type, target/currentTarget, mouse coords, key/code).
2. **Propagation & Phases** — demonstrate capture vs bubble order and experiment with `stopPropagation()`.
3. **Autosave with Debounce** — implement a debounced draft save to `localStorage` using `setTimeout`.

## Run
Open `starter/index.html` in a static server (e.g., VS Code Live Server or `python -m http.server`).

## Notes for Instructors
- Keep CSS minimal.
- Encourage students to use `addEventListener(...)` with options for capture.
- Discuss `event.target` vs `event.currentTarget` and input vs change events.
