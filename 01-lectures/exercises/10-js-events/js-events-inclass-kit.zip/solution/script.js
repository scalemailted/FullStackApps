// JS Events — In‑Class Exercise (Solution)
function writeLine(el, msg) {
  el.textContent = (msg + "\n" + el.textContent).slice(0, 4000);
}

document.addEventListener('DOMContentLoaded', () => {
  // ---------- (1) Event Logger ----------
  const loggerArea = document.getElementById('logger-area');
  const logEl = document.getElementById('log');
  const link = document.getElementById('link-in-logger');

  // prevent the demo link from navigating
  link.addEventListener('click', (e) => e.preventDefault());

  const events = ['click','mousedown','mouseup','mouseover','mouseout','mousemove','keyup','input'];
  // attach a single handler and inspect the event object
  const handler = (e) => {
    // note: currentTarget is where this handler is installed
    const base = `[${e.type}] target=${e.target.tagName} current=${e.currentTarget?.id || e.currentTarget?.tagName}`;
    let extra = '';
    if (e.type.startsWith('mouse')) {
      extra = ` x=${e.clientX} y=${e.clientY}`;
    } else if (e.type.startsWith('key')) {
      extra = ` key=${e.key} code=${e.code}`;
    } else if (e.type === 'input') {
      extra = ` value="${e.target.value}"`;
    }
    const line = base + extra;
    console.log(line, e);
    writeLine(logEl, line);
  };

  events.forEach(type => {
    loggerArea.addEventListener(type, handler);
    // Also listen on document for keyboard to capture focus outside area
    if (type.startsWith('key')) document.addEventListener(type, handler);
  });

  // ---------- (2) Propagation & Phases ----------
  const t2Form = document.getElementById('t2-form');
  const t2Div = document.getElementById('t2-div');
  const t2P = document.getElementById('t2-p');
  const t2Log = document.getElementById('t2-log');
  const t2Capture = document.getElementById('t2-capture');
  const t2StopOnDiv = document.getElementById('t2-stop-on-div');
  const t2StopOnP = document.getElementById('t2-stop-on-p');

  // (re)register listeners when capture checkbox toggles
  function registerPhaseListeners() {
    // Clean existing by cloning nodes (simple classroom trick)
    const newForm = t2Form.cloneNode(true);
    t2Form.replaceWith(newForm);
    // requery clones
    const form = document.getElementById('t2-form');
    const div = document.getElementById('t2-div');
    const p = document.getElementById('t2-p');

    function log(where, phase, e) {
      const msg = `${phase.toUpperCase()} on ${where} — target=${e.target.id||e.target.tagName} current=${e.currentTarget.id||e.currentTarget.tagName}`;
      console.log(msg);
      writeLine(t2Log, msg);
    }

    // capturing listeners
    form.addEventListener('click', (e)=>log('FORM','capture',e), {capture: t2Capture.checked});
    div.addEventListener('click', (e)=>{
      log('DIV','capture',e);
      if (t2StopOnDiv.checked) e.stopPropagation();
    }, {capture: t2Capture.checked});
    p.addEventListener('click', (e)=>{
      log('P','capture',e);
      if (t2StopOnP.checked) e.stopPropagation();
    }, {capture: t2Capture.checked});

    // bubbling listeners (always bubble phase handlers)
    form.addEventListener('click', (e)=>log('FORM','bubble',e));
    div.addEventListener('click', (e)=>{
      log('DIV','bubble',e);
      if (t2StopOnDiv.checked) e.stopPropagation();
    });
    p.addEventListener('click', (e)=>{
      log('P','bubble',e);
      if (t2StopOnP.checked) e.stopPropagation();
    });
  }

  registerPhaseListeners();
  t2Capture.addEventListener('change', registerPhaseListeners);
  t2StopOnDiv.addEventListener('change', ()=>writeLine(t2Log, `Stop on DIV: ${t2StopOnDiv.checked}`));
  t2StopOnP.addEventListener('change', ()=>writeLine(t2Log, `Stop on P: ${t2StopOnP.checked}`));

  // ---------- (3) Autosave with Debounce ----------
  const form = document.getElementById('profile-form');
  const statusEl = document.getElementById('status');
  const clearBtn = document.getElementById('clear-storage');
  const DRAFT_KEY = 'profileDraft';
  const DEBOUNCE_MS = 600;
  let saveTimer = null;

  // restore any existing draft
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        form.elements.name.value = data.name || '';
        form.elements.bio.value = data.bio || '';
        statusEl.textContent = 'Draft restored';
      }
    }
  } catch { /* ignore */ }

  function scheduleSave() {
    clearTimeout(saveTimer);
    statusEl.textContent = 'Saving…';
    saveTimer = setTimeout(() => {
      const fd = new FormData(form);
      const payload = { name: fd.get('name') || '', bio: fd.get('bio') || '' };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(payload));
      statusEl.textContent = 'Saved';
    }, DEBOUNCE_MS);
  }

  form.addEventListener('input', scheduleSave);

  clearBtn.addEventListener('click', () => {
    localStorage.removeItem(DRAFT_KEY);
    statusEl.textContent = 'Draft cleared';
  });

  // Simulate submit (no navigation)
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    statusEl.textContent = 'Submitted (simulated)';
  });
});
