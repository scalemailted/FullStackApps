// JS Events — In‑Class Exercise (Starter)
// Keep code small and focused on events. Avoid over‑engineering.

// Utility: write lines to a <pre> log
function writeLine(el, msg) {
  el.textContent = (msg + "\n" + el.textContent).slice(0, 4000);
}

document.addEventListener('DOMContentLoaded', () => {
  // ============ TODO (1): Event Logger ============
  // Goal: attach listeners to #logger-area for a few event types (click, mousedown, mouseup, keyup, input).
  //  • Log event.type, event.target.tagName, event.currentTarget.tagName.
  //  • For mouse events, include clientX/clientY; for keyboard, include key/code.
  //  • Print to #log (use writeLine) and console.
  //  • Prevent the demo link from navigating (preventDefault).
  // Hints: use addEventListener, a single shared handler, and check properties per type.

  const loggerArea = document.getElementById('logger-area');
  const logEl = document.getElementById('log');
  const link = document.getElementById('link-in-logger');

  // Your code here…


  // ============ TODO (2): Propagation & Phases ============
  // Goal: add click listeners to FORM, DIV, and P that show whether they fire during capture or bubble.
  //  • Use the checkbox #t2-capture to register outer listeners during capture when checked.
  //  • Support stopPropagation on DIV or P based on the checkboxes #t2-stop-on-div, #t2-stop-on-p.
  //  • Write the actual order to #t2-log (and console).
  // Hints: use addEventListener with {capture: true/false}. Checkboxes determine behavior inside the handlers.

  const t2Form = document.getElementById('t2-form');
  const t2Div = document.getElementById('t2-div');
  const t2P = document.getElementById('t2-p');
  const t2Log = document.getElementById('t2-log');
  const t2Capture = document.getElementById('t2-capture');
  const t2StopOnDiv = document.getElementById('t2-stop-on-div');
  const t2StopOnP = document.getElementById('t2-stop-on-p');

  // Your code here…


  // ============ TODO (3): Autosave with Debounce ============
  // Goal: implement autosave of #profile-form fields to localStorage with debounce via setTimeout.
  //  • When user types (input event), start/restart a timer (e.g., 600ms). On fire, save draft JSON to localStorage.
  //  • Show status text: "Saving…" while waiting, then "Saved" when persisted.
  //  • Restore any existing draft on load. Provide "Clear saved draft" button.
  // Hints: use clearTimeout + setTimeout, FormData to read values, and JSON.stringify.

  const form = document.getElementById('profile-form');
  const statusEl = document.getElementById('status');
  const clearBtn = document.getElementById('clear-storage');
  const DRAFT_KEY = 'profileDraft';

  // Your code here…

});
