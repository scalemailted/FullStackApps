// server.js                                   // File entry point name
import express from "express";                 // Import Express web framework
import session from "express-session";         // Import session middleware

const app = express();                         // Create an Express application instance

/* --- Session (minimal) --- */
const sessionConfig = {                        // Define basic session configuration
  secret: "dev-only-change-me",                // Key to sign the session cookie (change in real apps)
  resave: false,                               // Do not force-save session if nothing changed
  saveUninitialized: false,                    // Do not create empty sessions until we use req.session
};                                             // End sessionConfig object

function withSession() {                       // Named factory to create the session middleware
  return session(sessionConfig);               // Return middleware built from our config
}                                              // End withSession

/* --- Middleware (named) --- */
function countViews(req, _res, next) {         // Named middleware to track per-session page views
  req.session.views = (req.session.views || 0) + 1; // Initialize/increment a views counter on the session
  console.log("sessionID:", req.sessionID, "views:", req.session.views); // Log session id + views to server
  next();                                      // Pass control to the next middleware/route
}                                              // End countViews

/* --- Route (named) --- */
function showSession(req, res) {               // Named handler for GET /
  res.type("html").send(                       // Set Content-Type to HTML and send a response
    `<pre>sessionID: ${req.sessionID}\nviews: ${req.session.views}</pre>` // Minimal HTML showing session data
  );                                           // End send
}                                              // End showSession

/* --- Wire + Boot --- */
app.use(withSession());                        // Install the session middleware globally
app.use(countViews);                           // Install our counting/logger middleware globally
app.get("/", showSession);                     // Map GET / to the showSession handler

const PORT = process.env.PORT || 3000;         // Choose port from env or default to 3000
function onListen() {                          // Named callback when server starts listening
  console.log(`http://localhost:${PORT}`);     // Print the local URL for convenience
}                                              // End onListen
app.listen(PORT, onListen);                    // Start the HTTP server

