class WorldScene extends Phaser.Scene
{
	constructor() {
		super('world');
		this.tile_size = 32;
		this.width  = 8 * this.tile_size;
		this.height = 8 * this.tile_size;
	}

	preload() {
		this.load.path = 'assets/';
		this.load.tilemapTiledJSON('worldMap', 'worldMap.json');
		this.load.image('tiles', 'tiles.png');
		this.load.spritesheet('player','player.png', { frameWidth:24, frameHeight:30 });
		this.load.spritesheet('tilemap', 'items.png', { frameWidth:32, frameHeight:32 });
	}

	create() {
		this.create_map();
		this.player = new Player(this);
		this.setup_camera();
		this.create_objects();
		this.hud = new Hud(this);
		this.create_collisions();
	}

	create_collisions(){
		this.physics.add.collider(this.player, this.layer);
		this.physics.add.collider(this.player, this.groupDoors);                           // doors solid
		this.physics.add.overlap(this.player, this.groupKeys, this.key_take, null, this);  // keys
		this.physics.add.overlap(this.player, this.groupScrolls, this.hud.show_story, null, this.hud); // scrolls
	}

	update() {
		this.player.move();
		this.hud.hide();
	}

	create_map() {
		this.map = this.make.tilemap({ key:'worldMap' });
		const tiles = this.map.addTilesetImage('tiles');

		this.layer = this.map.createLayer('tiles', tiles, 0, 0)

		this.layer.setCollision([2,3,4,5,6,7,8,9,10,11,18,24,25,26]);
	}

	setup_camera() {
		this.cameras.main.startFollow(this.player);
		this.cameras.main.setBounds(0,0,this.map.widthInPixels, this.map.heightInPixels);
  	}
  	

	create_objects() {
		this.groupKeys    = this.map.createFromObjects('items', { gid:95,  key:'tilemap', frame:0 });
		this.groupScrolls = this.map.createFromObjects('items', { gid:96,  key:'tilemap', frame:1 });
		this.groupSword   = this.map.createFromObjects('items', { gid:97,  key:'tilemap', frame:2 });
		this.groupDoors   = this.map.createFromObjects('items', { gid:101, key:'tilemap', frame:6 });

		this.setup_objects(101, this.groupDoors);
		this.setup_objects( 95, this.groupKeys);
		this.setup_objects( 96, this.groupScrolls);
	}

	setup_objects(gid, objGroup)
	{
		//enable keys into physics system
		for (var obj of objGroup)
		{
			this.physics.add.existing(obj);
			obj.body.immovable = true;
		}

		//Add special properties to objects in group from object layer
		var groupProps = this.map.filterObjects('items', (obj) => obj.gid === gid ) 
		for (var index in objGroup)
		{
			//assign the properties into this object
			Object.assign( objGroup[index], groupProps[index].properties );
		}
	}

	// Pick up a key
	key_take(player, key) {
		if ('key_id' in key) {
			this.door_open(key.key_id);
		}
		if ('message' in key) {
			this.hud.show_message(key.message);
		}
		key.destroy();
	}

	// Open all doors that share the same key_id (legacy used loose equality)
	door_open(key_id) {
		for (const door of this.groupDoors) {
			if (door && key_id == door.key_id) { // == on purpose to allow "0" vs 0
				door.destroy();
			}
		}
	}
}
