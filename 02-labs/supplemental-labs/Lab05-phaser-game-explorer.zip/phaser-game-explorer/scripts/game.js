var config = 
{
	type: Phaser.CANVAS,
	width: 32 * 8,
	height: 32 * 8,
	zoom: 4,
	pixelArt: true,
	scene: [ WorldScene ],
	physics: { default:'arcade', arcade:{ gravity:0 } }
};

var game = new Phaser.Game(config);