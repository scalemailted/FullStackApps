class Player extends Phaser.Physics.Arcade.Sprite
{
	constructor(scene)
	{
		super(scene, 0, 0, 'player');

		let start = scene.map.findObject('items', obj=> obj.type === 'start');
		this.x = start.x;
		this.y = start.y;
		this.depth = 1;
		this.speed = 160;

		scene.add.existing(this);
		scene.physics.add.existing(this);

        // Receives every single key down event, regardless of origin or key
    	this.arrowKeys = new Set()
    	scene.input.keyboard.on('keydown', this.updateArrowKeys,this );
    	scene.input.keyboard.on('keyup',   this.updateArrowKeys,this );

        this.setupAnimations(scene);
	}

	updateArrowKeys(event)
	{
		if (event.type === 'keydown')
			this.arrowKeys.add(event.key);
		else if (event.type === 'keyup')
			this.arrowKeys.delete(event.key);
	}

    //move player
    move() {
        // reset velocity
        this.body.velocity.x = 0;
        this.body.velocity.y = 0;
        var move_animation = '';

        // take care of character movement
        if ( this.arrowKeys.has("ArrowUp")) 
        {
            this.body.velocity.y = -this.speed;
            move_animation = 'up';
        } 
        if ( this.arrowKeys.has("ArrowDown")) 
        {
            this.body.velocity.y = this.speed;
            move_animation = 'down';
        }
        if ( this.arrowKeys.has("ArrowLeft" )) 
        {
            this.body.velocity.x = -this.speed;
            move_animation = 'left';
        } 
        if ( this.arrowKeys.has("ArrowRight" )) 
        {
            this.body.velocity.x = this.speed;
            move_animation = 'right';
        }

        // if there's an animation
        if ( move_animation ) {

            this.anims.play(move_animation, true);
        }
        else
        {
            // set stationary poses
            this.anims.isPlaying = false;
        }
    }

    setupAnimations(scene)
    {
        scene.anims.create({
            key: 'down',
            frames: scene.anims.generateFrameNumbers('player', { start: 0, end: 1 }),
            frameRate: 6,
            repeat: -1
        });
        // this.player.animations.add( 'up', [ 3, 4, 3, 5 ], 4, true );
        scene.anims.create({
            key: 'up',
            frames: scene.anims.generateFrameNumbers('player', { start: 4, end: 5 }),
            frameRate: 6,
            repeat: -1
        });
        // this.player.animations.add( 'right', [ 7, 8 ], 4, true );
        scene.anims.create({
            key: 'right',
            frames: scene.anims.generateFrameNumbers('player', { start: 6, end: 7 }),
            frameRate: 6,
            repeat: -1
        });
        // this.player.animations.add( 'left', [ 10, 11 ], 4, true );
        scene.anims.create({
            key: 'left',
            frames: scene.anims.generateFrameNumbers('player', { start: 2, end: 3 }),
            frameRate: 6,
            repeat: -1
        });
    }
}
