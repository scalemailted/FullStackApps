class Hud extends Phaser.GameObjects.Text
{
	constructor(scene)
	{
		super( scene, scene.width/2, scene.tile_size, '' );
		this.setStyle( {color:'#ffffff', fontSize: 20, fontFamily: "Papyrus", align:"center"} );
		this.depth = 2
        this.setOrigin(0.5, 0);
        this.setScrollFactor(0,0);
        this.is_story = false;
        this.is_message = false;

        scene.add.existing(this);
        this.scene = scene;

        this.storylines = {
            0: "Explore the World\n& find the sword\nto win the game\n",
            1: "The Key to the Dungeon\nis to the Far East\nin the stony valley\n",
            2: "The sword is\nin the armory\nwithin the dungeon\nto the far north\n"
        };
	}

	show_message( message ) 
    {
        this.is_message = true;
        this.setText(message);
        this.scene.time.delayedCall( 2500, function(){ this.is_message = false }, [], this);
    }

    show_story( player, scroll )
    {
        this.is_story = true;
        let story = this.storylines[scroll.story_id]
        this.setText(story);
    }

    hide()
    {
    	if ( this.is_story == false && this.is_message == false)
            this.setText("");
        this.is_story = false;
    }
}